// Japanese translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "現在のページをダウンロード",
  worksOnAllSites: "yt-dlpがサポートするすべてのサイトで動作します",
  checkingServer: "サーバーを確認中...",
  serverConnected: "サーバーに接続済み",
  serverDisconnected: "サーバーが切断されています",
  settings: "設定",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "MyTubeサーバー接続を設定",
  serverUrl: "MyTubeサーバー URL",
  serverUrlHint: "MyTubeサーバーのURLを入力してください（例：http://localhost:3000）",
  testConnection: "接続をテスト",
  testing: "テスト中...",
  saveSettings: "設定を保存",
  settingsSaved: "設定が正常に保存されました！",
  settingsError: "設定の保存中にエラーが発生しました：{error}",
  connectionSuccess: "✓ 接続成功！",
  connectionFailed: "✗ {error}",
  footerText: "設定後、動画サイトにアクセスしてワンクリックで動画をダウンロード！",
  
  // Content Script
  downloadToMytube: "📥 MyTubeにダウンロード",
  sending: "⏳ 送信中...",
  downloadQueued: "ダウンロードをキューに追加しました！",
  downloadFailed: "ダウンロードのキュー追加に失敗しました",
  unsupportedSite: "サポートされていないサイト",
  couldNotDetectUrl: "動画URLを検出できませんでした",
  failedToConnect: "拡張機能への接続に失敗しました",
};
