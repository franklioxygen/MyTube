// German translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Aktuelle Seite herunterladen",
  worksOnAllSites: "Funktioniert auf allen von yt-dlp unterstützten Websites",
  checkingServer: "Server wird überprüft...",
  serverConnected: "Server verbunden",
  serverDisconnected: "Server nicht verbunden",
  settings: "Einstellungen",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "MyTube-Serververbindung konfigurieren",
  serverUrl: "MyTube Server URL",
  serverUrlHint: "Geben Sie die URL Ihres MyTube-Servers ein (z.B. http://localhost:3000)",
  testConnection: "Verbindung testen",
  testing: "Teste...",
  saveSettings: "Einstellungen Speichern",
  settingsSaved: "Einstellungen erfolgreich gespeichert!",
  settingsError: "Fehler beim Speichern der Einstellungen: {error}",
  connectionSuccess: "✓ Verbindung erfolgreich!",
  connectionFailed: "✗ {error}",
  footerText: "Nach der Konfiguration besuchen Sie Videoseiten, um Videos mit einem Klick herunterzuladen!",
  
  // Content Script
  downloadToMytube: "📥 Zu MyTube herunterladen",
  sending: "⏳ Wird gesendet...",
  downloadQueued: "Download erfolgreich in Warteschlange eingereiht!",
  downloadFailed: "Download konnte nicht in Warteschlange eingereiht werden",
  unsupportedSite: "Nicht unterstützte Website",
  couldNotDetectUrl: "Video-URL konnte nicht erkannt werden",
  failedToConnect: "Verbindung zur Erweiterung fehlgeschlagen",
};
