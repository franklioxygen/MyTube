// Korean translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "현재 페이지 다운로드",
  worksOnAllSites: "yt-dlp가 지원하는 모든 사이트에서 작동합니다",
  checkingServer: "서버 확인 중...",
  serverConnected: "서버 연결됨",
  serverDisconnected: "서버 연결 끊김",
  settings: "설정",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "MyTube 서버 연결 구성",
  serverUrl: "MyTube 서버 URL",
  serverUrlHint: "MyTube 서버의 URL을 입력하세요 (예: http://localhost:3000)",
  testConnection: "연결 테스트",
  testing: "테스트 중...",
  saveSettings: "설정 저장",
  settingsSaved: "설정이 성공적으로 저장되었습니다!",
  settingsError: "설정 저장 중 오류 발생: {error}",
  connectionSuccess: "✓ 연결 성공!",
  connectionFailed: "✗ {error}",
  footerText: "구성 후 동영상 웹사이트를 방문하여 클릭 한 번으로 동영상을 다운로드하세요!",
  
  // Content Script
  downloadToMytube: "📥 MyTube로 다운로드",
  sending: "⏳ 전송 중...",
  downloadQueued: "다운로드가 성공적으로 큐에 추가되었습니다!",
  downloadFailed: "다운로드 큐 추가 실패",
  unsupportedSite: "지원되지 않는 사이트",
  couldNotDetectUrl: "동영상 URL을 감지할 수 없습니다",
  failedToConnect: "확장 프로그램에 연결 실패",
};
