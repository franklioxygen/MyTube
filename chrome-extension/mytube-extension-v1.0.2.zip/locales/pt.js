// Portuguese translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Baixar página atual",
  worksOnAllSites: "Funciona em todos os sites suportados pelo yt-dlp",
  checkingServer: "Verificando servidor...",
  serverConnected: "Servidor conectado",
  serverDisconnected: "Servidor desconectado",
  settings: "Configurações",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "Configurar conexão do servidor MyTube",
  serverUrl: "URL do servidor MyTube",
  serverUrlHint: "Digite a URL do seu servidor MyTube (ex. http://localhost:3000)",
  testConnection: "Testar Conexão",
  testing: "Testando...",
  saveSettings: "Salvar Configurações",
  settingsSaved: "Configurações salvas com sucesso!",
  settingsError: "Erro ao salvar configurações: {error}",
  connectionSuccess: "✓ Conexão bem-sucedida!",
  connectionFailed: "✗ {error}",
  footerText: "Após configurar, visite sites de vídeo para baixar vídeos com um clique!",
  
  // Content Script
  downloadToMytube: "📥 Baixar para MyTube",
  sending: "⏳ Enviando...",
  downloadQueued: "Download adicionado à fila com sucesso!",
  downloadFailed: "Falha ao adicionar download à fila",
  unsupportedSite: "Site não suportado",
  couldNotDetectUrl: "Não foi possível detectar a URL do vídeo",
  failedToConnect: "Falha ao conectar à extensão",
};
