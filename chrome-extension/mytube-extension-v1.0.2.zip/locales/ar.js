// Arabic translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "تنزيل الصفحة الحالية",
  worksOnAllSites: "يعمل على جميع المواقع المدعومة من yt-dlp",
  checkingServer: "جارٍ التحقق من الخادم...",
  serverConnected: "الخادم متصل",
  serverDisconnected: "الخادم غير متصل",
  settings: "الإعدادات",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "تكوين اتصال خادم MyTube",
  serverUrl: "رابط خادم MyTube",
  serverUrlHint: "أدخل رابط خادم MyTube الخاص بك (مثال: http://localhost:3000)",
  testConnection: "اختبار الاتصال",
  testing: "جارٍ الاختبار...",
  saveSettings: "حفظ الإعدادات",
  settingsSaved: "تم حفظ الإعدادات بنجاح!",
  settingsError: "خطأ في حفظ الإعدادات: {error}",
  connectionSuccess: "✓ نجح الاتصال!",
  connectionFailed: "✗ {error}",
  footerText: "بعد التكوين، قم بزيارة مواقع الفيديو لتنزيل مقاطع الفيديو بنقرة واحدة!",
  
  // Content Script
  downloadToMytube: "📥 تنزيل إلى MyTube",
  sending: "⏳ جارٍ الإرسال...",
  downloadQueued: "تمت إضافة التنزيل إلى قائمة الانتظار بنجاح!",
  downloadFailed: "فشل في إضافة التنزيل إلى قائمة الانتظار",
  unsupportedSite: "موقع غير مدعوم",
  couldNotDetectUrl: "تعذر اكتشاف رابط الفيديو",
  failedToConnect: "فشل الاتصال بالامتداد",
};
