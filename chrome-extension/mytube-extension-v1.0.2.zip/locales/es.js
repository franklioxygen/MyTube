// Spanish translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Descargar página actual",
  worksOnAllSites: "Funciona en todos los sitios compatibles con yt-dlp",
  checkingServer: "Comprobando servidor...",
  serverConnected: "Servidor conectado",
  serverDisconnected: "Servidor desconectado",
  settings: "Configuración",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "Configurar la conexión del servidor MyTube",
  serverUrl: "URL del servidor MyTube",
  serverUrlHint: "Ingrese la URL de su servidor MyTube (ej. http://localhost:3000)",
  testConnection: "Probar Conexión",
  testing: "Probando...",
  saveSettings: "Guardar Configuración",
  settingsSaved: "¡Configuración guardada exitosamente!",
  settingsError: "Error al guardar la configuración: {error}",
  connectionSuccess: "✓ ¡Conexión exitosa!",
  connectionFailed: "✗ {error}",
  footerText: "¡Después de configurar, visite sitios web de video para descargar videos con un clic!",
  
  // Content Script
  downloadToMytube: "📥 Descargar a MyTube",
  sending: "⏳ Enviando...",
  downloadQueued: "¡Descarga puesta en cola exitosamente!",
  downloadFailed: "Error al poner la descarga en cola",
  unsupportedSite: "Sitio no compatible",
  couldNotDetectUrl: "No se pudo detectar la URL del video",
  failedToConnect: "Error al conectar con la extensión",
};
