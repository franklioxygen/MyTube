// Chinese translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "下载当前页面",
  worksOnAllSites: "支持所有 yt-dlp 支持的网站",
  checkingServer: "正在检查服务器...",
  serverConnected: "服务器已连接",
  serverDisconnected: "服务器未连接",
  settings: "设置",

  // Options
  mytubeDownloader: "MyTube 下载器",
  configureConnection: "配置您的 MyTube 服务器连接",
  serverUrl: "MyTube 服务器 URL",
  serverUrlHint: "输入您的 MyTube 服务器 URL（例如：http://localhost:3000）",
  testConnection: "测试连接",
  testing: "测试中...",
  saveSettings: "保存设置",
  settingsSaved: "设置保存成功！",
  settingsError: "保存设置时出错：{error}",
  connectionSuccess: "✓ 连接成功！",
  connectionFailed: "✗ {error}",
  footerText: "配置完成后，访问视频网站即可一键下载视频！",

  // Content Script
  downloadToMytube: "📥 下载到 MyTube",
  sending: "⏳ 发送中...",
  downloadQueued: "下载已成功加入队列！",
  downloadFailed: "加入下载队列失败",
  unsupportedSite: "不支持的网站",
  couldNotDetectUrl: "无法检测视频 URL",
  failedToConnect: "无法连接到扩展程序",
};
