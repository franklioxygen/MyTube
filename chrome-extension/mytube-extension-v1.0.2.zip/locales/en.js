// English translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Download Current Page",
  worksOnAllSites: "Works on all yt-dlp supported sites",
  checkingServer: "Checking server...",
  serverConnected: "Server connected",
  serverDisconnected: "Server disconnected",
  settings: "Settings",

  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "Configure your MyTube server connection",
  serverUrl: "MyTube Server URL",
  serverUrlHint:
    "Enter the URL of your MyTube server (e.g., http://localhost:3000)",
  testConnection: "Test Connection",
  testing: "Testing...",
  saveSettings: "Save Settings",
  settingsSaved: "Settings saved successfully!",
  settingsError: "Error saving settings: {error}",
  connectionSuccess: "✓ Connection successful!",
  connectionFailed: "✗ {error}",
  footerText:
    "After configuring, visit video websites to download videos with one click!",

  // Content Script
  downloadToMytube: "📥 Download to MyTube",
  sending: "⏳ Sending...",
  downloadQueued: "Download queued successfully!",
  downloadFailed: "Failed to queue download",
  unsupportedSite: "Unsupported site",
  couldNotDetectUrl: "Could not detect video URL",
  failedToConnect: "Failed to connect to extension",
};
