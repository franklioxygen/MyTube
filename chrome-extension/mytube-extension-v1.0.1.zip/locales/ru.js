// Russian translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Скачать текущую страницу",
  worksOnAllSites: "Работает на всех сайтах, поддерживаемых yt-dlp",
  checkingServer: "Проверка сервера...",
  serverConnected: "Сервер подключен",
  serverDisconnected: "Сервер отключен",
  settings: "Настройки",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "Настроить подключение к серверу MyTube",
  serverUrl: "URL сервера MyTube",
  serverUrlHint: "Введите URL вашего сервера MyTube (например, http://localhost:3000)",
  testConnection: "Тестировать подключение",
  testing: "Тестирование...",
  saveSettings: "Сохранить настройки",
  settingsSaved: "Настройки успешно сохранены!",
  settingsError: "Ошибка при сохранении настроек: {error}",
  connectionSuccess: "✓ Подключение успешно!",
  connectionFailed: "✗ {error}",
  footerText: "После настройки посетите видеосайты для загрузки видео одним кликом!",
  
  // Content Script
  downloadToMytube: "📥 Скачать в MyTube",
  sending: "⏳ Отправка...",
  downloadQueued: "Загрузка успешно добавлена в очередь!",
  downloadFailed: "Не удалось добавить загрузку в очередь",
  unsupportedSite: "Неподдерживаемый сайт",
  couldNotDetectUrl: "Не удалось обнаружить URL видео",
  failedToConnect: "Не удалось подключиться к расширению",
};
