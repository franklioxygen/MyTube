// French translations for Chrome Extension
window.currentTranslations = {
  // Popup
  mytube: "MyTube",
  downloadCurrentPage: "Télécharger la page actuelle",
  worksOnAllSites: "Fonctionne sur tous les sites pris en charge par yt-dlp",
  checkingServer: "Vérification du serveur...",
  serverConnected: "Serveur connecté",
  serverDisconnected: "Serveur déconnecté",
  settings: "Paramètres",
  
  // Options
  mytubeDownloader: "MyTube Downloader",
  configureConnection: "Configurer la connexion au serveur MyTube",
  serverUrl: "URL du serveur MyTube",
  serverUrlHint: "Entrez l'URL de votre serveur MyTube (ex. http://localhost:3000)",
  testConnection: "Tester la connexion",
  testing: "Test en cours...",
  saveSettings: "Enregistrer les paramètres",
  settingsSaved: "Paramètres enregistrés avec succès !",
  settingsError: "Erreur lors de l'enregistrement des paramètres : {error}",
  connectionSuccess: "✓ Connexion réussie !",
  connectionFailed: "✗ {error}",
  footerText: "Après configuration, visitez des sites de vidéos pour télécharger des vidéos en un clic !",
  
  // Content Script
  downloadToMytube: "📥 Télécharger vers MyTube",
  sending: "⏳ Envoi en cours...",
  downloadQueued: "Téléchargement mis en file d'attente avec succès !",
  downloadFailed: "Échec de la mise en file d'attente du téléchargement",
  unsupportedSite: "Site non pris en charge",
  couldNotDetectUrl: "Impossible de détecter l'URL de la vidéo",
  failedToConnect: "Échec de la connexion à l'extension",
};
